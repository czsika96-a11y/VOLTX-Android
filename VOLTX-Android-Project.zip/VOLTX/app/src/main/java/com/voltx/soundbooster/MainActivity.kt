package com.voltx.soundbooster

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlin.math.roundToInt

private val Night = Color(0xFF070810)
private val Panel = Color(0xFF111426)
private val Violet = Color(0xFF9B5CFF)
private val Cyan = Color(0xFF35DDF2)
private val Muted = Color(0xFF9BA3B8)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val controller = AudioController(applicationContext)
        setContent {
            val vm: SoundViewModel = viewModel(factory = SoundViewModel.factory(controller))
            VoltxTheme { VoltxScreen(vm) }
        }
    }
}

@Composable
private fun VoltxTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            background = Night, surface = Panel, primary = Violet,
            secondary = Cyan, onBackground = Color.White, onSurface = Color.White
        ),
        content = content
    )
}

@Composable
private fun VoltxScreen(vm: SoundViewModel) {
    val state by vm.state.collectAsState()
    val ar = state.arabic
    val title = if (ar) "مُعزّز الصوت" else "SOUND BOOSTER"
    val presets = listOf("Gaming", "Music", "Movies", "Voice")
    val labels = if (ar) listOf("ألعاب", "موسيقى", "أفلام", "صوت") else presets

    Surface(Modifier.fillMaxSize(), color = Night) {
        Column(
            Modifier.fillMaxSize().padding(horizontal = 20.dp, vertical = 14.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("VOLTX", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Black, letterSpacing = 3.sp)
                    Text("ULTIMATE SOUND BOOSTER", color = Cyan, fontSize = 9.sp, letterSpacing = 2.sp)
                }
                IconButton(onClick = vm::toggleLanguage) {
                    Icon(Icons.Default.Language, contentDescription = "Language", tint = Cyan)
                }
            }
            Spacer(Modifier.height(18.dp))
            Text(title, color = Muted, fontSize = 12.sp, letterSpacing = 2.sp)
            Spacer(Modifier.height(14.dp))
            VolumeOrb(state.volumePercent, ar)
            Spacer(Modifier.height(8.dp))
            Text(
                if (ar) "مستوى صوت الوسائط" else "MEDIA VOLUME",
                color = Muted, fontSize = 11.sp, letterSpacing = 1.5.sp
            )
            Slider(
                value = state.volumePercent / 100f,
                onValueChange = { vm.setVolumePercent((it * 100).roundToInt()) },
                modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp),
                colors = SliderDefaults.colors(
                    thumbColor = Cyan, activeTrackColor = Violet, inactiveTrackColor = Color(0xFF30334A)
                )
            )
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("0%", color = Muted, fontSize = 10.sp)
                Text("${state.volumePercent}%", color = Cyan, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Text("100%", color = Muted, fontSize = 10.sp)
            }
            Spacer(Modifier.height(12.dp))
            Button(
                onClick = vm::toggleBoost,
                modifier = Modifier.fillMaxWidth().height(54.dp),
                shape = RoundedCornerShape(18.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (state.boostEnabled) Violet else Color(0xFF25213A)
                )
            ) {
                Text(
                    if (state.boostEnabled) (if (ar) "BOOST مفعّل" else "BOOST ACTIVE")
                    else (if (ar) "تفعيل BOOST" else "ACTIVATE BOOST"),
                    fontWeight = FontWeight.ExtraBold, letterSpacing = 2.sp
                )
            }
            Spacer(Modifier.height(16.dp))
            SectionTitle(if (ar) "الملفات الصوتية" else "SOUND PRESETS")
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(presets.indices.toList()) { index ->
                    FilterChip(
                        selected = state.preset == presets[index],
                        onClick = { vm.applyPreset(presets[index]) },
                        label = { Text(labels[index]) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = Violet.copy(alpha = .28f),
                            selectedLabelColor = Color.White
                        )
                    )
                }
            }
            Spacer(Modifier.height(12.dp))
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                SectionTitle(if (ar) "المعادل الصوتي" else "EQUALIZER")
                Spacer(Modifier.weight(1f))
                Text(
                    if (state.equalizerAvailable) "● ${if (ar) "متاح" else "AVAILABLE"}"
                    else "● ${if (ar) "غير مدعوم" else "UNAVAILABLE"}",
                    color = if (state.equalizerAvailable) Cyan else Color(0xFFFFB45E),
                    fontSize = 9.sp
                )
            }
            if (state.eqBands.isNotEmpty()) {
                state.eqBands.forEachIndexed { index, band ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(band.label, color = Muted, fontSize = 10.sp, modifier = Modifier.width(48.dp))
                        Slider(
                            value = band.normalized,
                            onValueChange = { vm.setEqBand(index, it) },
                            enabled = state.equalizerAvailable,
                            modifier = Modifier.weight(1f).height(34.dp),
                            colors = SliderDefaults.colors(thumbColor = Cyan, activeTrackColor = Violet)
                        )
                        Text("${band.db} dB", color = Color.White, fontSize = 10.sp, modifier = Modifier.width(48.dp), textAlign = TextAlign.End)
                    }
                }
            } else {
                Text(
                    if (ar) "لا يوفّر الجهاز نطاقات Equalizer قابلة للتحكم." else "No controllable EQ bands exposed by this device.",
                    color = Muted, fontSize = 11.sp
                )
            }
            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                EffectCard("BASS BOOST", state.bassAvailable, state.bassEnabled, if (ar) "جهير" else "Bass", Modifier.weight(1f)) { vm.toggleBass() }
                EffectCard("VIRTUALIZER", state.virtualizerAvailable, state.virtualizerEnabled, if (ar) "محيطي" else "Surround", Modifier.weight(1f)) { vm.toggleVirtualizer() }
            }
            Spacer(Modifier.height(12.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text(if (ar) "حالة محرك الصوت" else "AUDIO ENGINE STATUS", color = Muted, fontSize = 10.sp, letterSpacing = 1.sp)
                TextButton(onClick = vm::reset) {
                    Icon(Icons.Default.Refresh, null, tint = Cyan, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(4.dp))
                    Text(if (ar) "إعادة ضبط" else "RESET", color = Cyan, fontSize = 10.sp)
                }
            }
            Text(
                state.statusMessage,
                color = if (state.statusOk) Cyan else Color(0xFFFFB45E),
                fontSize = 10.sp, textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(6.dp))
            Text(
                if (ar) "تنبيه: الصوت المرتفع قد يضر السمع. لا يمكن تجاوز حدود النظام أو قدرات السماعة." else "Warning: High volume can damage hearing. System and speaker limits cannot be bypassed.",
                color = Muted, fontSize = 9.sp, textAlign = TextAlign.Center,
                lineHeight = 13.sp
            )
        }
    }
}

@Composable
private fun VolumeOrb(percent: Int, arabic: Boolean) {
    val scale by androidx.compose.animation.core.animateFloatAsState(
        targetValue = 1f + (percent / 100f) * .035f,
        label = "orbScale"
    )
    Box(
        Modifier.size(190.dp).scale(scale)
            .background(Brush.radialGradient(listOf(Violet.copy(alpha = .35f), Cyan.copy(alpha = .08f), Night)), CircleShape)
            .border(2.dp, Brush.linearGradient(listOf(Violet, Cyan)), CircleShape),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(Icons.Default.VolumeUp, null, tint = Cyan, modifier = Modifier.size(27.dp))
            Text("$percent", color = Color.White, fontSize = 48.sp, fontWeight = FontWeight.Black)
            Text(if (arabic) "بالمئة" else "PERCENT", color = Muted, fontSize = 9.sp, letterSpacing = 2.sp)
        }
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(text, color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
}

@Composable
private fun EffectCard(
    heading: String, available: Boolean, enabled: Boolean, sub: String,
    modifier: Modifier = Modifier, onClick: () -> Unit
) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(16.dp)) {
        Column(Modifier.padding(12.dp)) {
            Text(heading, color = Muted, fontSize = 9.sp, letterSpacing = 1.sp)
            Spacer(Modifier.height(4.dp))
            Text(sub, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    when { !available -> "UNSUPPORTED"; enabled -> "ON"; else -> "OFF" },
                    color = when { !available -> Color(0xFFFFB45E); enabled -> Cyan; else -> Muted },
                    fontSize = 9.sp, modifier = Modifier.weight(1f)
                )
                Switch(checked = enabled, onCheckedChange = { onClick() }, enabled = available)
            }
        }
    }
}
