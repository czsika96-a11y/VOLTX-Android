package com.voltx.soundbooster

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class ScreenState(
    val volumePercent: Int = 50,
    val boostEnabled: Boolean = false,
    val equalizerAvailable: Boolean = false,
    val bassAvailable: Boolean = false,
    val bassEnabled: Boolean = false,
    val virtualizerAvailable: Boolean = false,
    val virtualizerEnabled: Boolean = false,
    val eqBands: List<EqBand> = emptyList(),
    val statusMessage: String = "",
    val statusOk: Boolean = false,
    val arabic: Boolean = true,
    val preset: String = "Music"
)

class SoundViewModel(private val controller: AudioController, context: Context) : ViewModel() {
    private val prefs = context.getSharedPreferences("voltx_settings", Context.MODE_PRIVATE)
    private val _state = MutableStateFlow(ScreenState(arabic = prefs.getBoolean("arabic", true)))
    val state: StateFlow<ScreenState> = _state.asStateFlow()

    init {
        refresh()
        val savedPreset = prefs.getString("preset", "Music") ?: "Music"
        _state.value = _state.value.copy(preset = savedPreset)
        controller.applyPreset(savedPreset)
        refresh()
    }

    fun refresh() {
        val s = controller.snapshot()
        _state.value = _state.value.copy(
            volumePercent = s.volumePercent,
            boostEnabled = s.boostEnabled,
            equalizerAvailable = s.equalizerAvailable,
            bassAvailable = s.bassAvailable,
            bassEnabled = s.bassEnabled,
            virtualizerAvailable = s.virtualizerAvailable,
            virtualizerEnabled = s.virtualizerEnabled,
            eqBands = s.eqBands,
            statusMessage = s.statusMessage,
            statusOk = s.statusOk
        )
    }

    fun setVolumePercent(value: Int) {
        controller.setVolumePercent(value)
        refresh()
    }

    fun toggleBoost() {
        controller.setBoost(!_state.value.boostEnabled)
        refresh()
    }

    fun toggleBass() {
        controller.setBass(!_state.value.bassEnabled)
        refresh()
    }

    fun toggleVirtualizer() {
        controller.setVirtualizer(!_state.value.virtualizerEnabled)
        refresh()
    }

    fun setEqBand(index: Int, value: Float) {
        controller.setEqBand(index, value)
        refresh()
    }

    fun applyPreset(name: String) {
        controller.applyPreset(name)
        prefs.edit().putString("preset", name).apply()
        _state.value = _state.value.copy(preset = name)
        refresh()
    }

    fun reset() {
        controller.reset()
        prefs.edit().remove("preset").apply()
        _state.value = _state.value.copy(preset = "Music")
        refresh()
    }

    fun toggleLanguage() {
        val next = !_state.value.arabic
        prefs.edit().putBoolean("arabic", next).apply()
        _state.value = _state.value.copy(arabic = next)
    }

    override fun onCleared() {
        controller.release()
    }

    companion object {
        fun factory(controller: AudioController): ViewModelProvider.Factory =
            object : ViewModelProvider.Factory {
                @Suppress("UNCHECKED_CAST")
                override fun <T : ViewModel> create(modelClass: Class<T>): T {
                    throw IllegalStateException("Use create(modelClass, extras) through the Activity factory")
                }
                @Suppress("UNCHECKED_CAST")
                override fun <T : ViewModel> create(
                    modelClass: Class<T>,
                    extras: androidx.lifecycle.viewmodel.CreationExtras
                ): T {
                    val app = extras[androidx.lifecycle.ViewModelProvider.AndroidViewModelFactory.APPLICATION_KEY]
                        ?: throw IllegalStateException("Application unavailable")
                    return SoundViewModel(controller, app) as T
                }
            }
    }
}
