package com.voltx.soundbooster

import android.content.Context
import android.media.AudioManager
import android.media.audiofx.BassBoost
import android.media.audiofx.Equalizer
import android.media.audiofx.Virtualizer

data class EqBand(val label: String, val normalized: Float, val db: Int)

data class AudioSnapshot(
    val volumePercent: Int,
    val boostEnabled: Boolean,
    val equalizerAvailable: Boolean,
    val bassAvailable: Boolean,
    val bassEnabled: Boolean,
    val virtualizerAvailable: Boolean,
    val virtualizerEnabled: Boolean,
    val eqBands: List<EqBand>,
    val statusMessage: String,
    val statusOk: Boolean
)

class AudioController(context: Context) {
    private val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private var equalizer: Equalizer? = null
    private var bassBoost: BassBoost? = null
    private var virtualizer: Virtualizer? = null
    private var eqMin: Int = -1500
    private var eqMax: Int = 1500
    private var boost = false

    init { initializeEffects() }

    private fun initializeEffects() {
        // Session 0 requests global output-mix processing where the device permits it.
        // Android/OEMs may reject or ignore this; callers expose actual creation status.
        try { equalizer = Equalizer(0, 0).also { it.enabled = false } } catch (_: Exception) { equalizer = null }
        try { bassBoost = BassBoost(0, 0).also { it.enabled = false } } catch (_: Exception) { bassBoost = null }
        try { virtualizer = Virtualizer(0, 0).also { it.enabled = false } } catch (_: Exception) { virtualizer = null }
        try {
            equalizer?.bandLevelRange?.let {
                eqMin = it[0].toInt()
                eqMax = it[1].toInt()
            }
        } catch (_: Exception) { equalizer = null }
    }

    fun snapshot(): AudioSnapshot {
        val max = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
        val current = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC)
        val bands = readBands()
        val bassOk = safe { bassBoost?.strengthSupported == true } ?: false
        val virtOk = safe { virtualizer?.strengthSupported == true } ?: false
        return AudioSnapshot(
            volumePercent = (current * 100f / max).toInt().coerceIn(0, 100),
            boostEnabled = boost,
            equalizerAvailable = equalizer != null && bands.isNotEmpty(),
            bassAvailable = bassBoost != null && bassOk,
            bassEnabled = safe { bassBoost?.enabled == true } ?: false,
            virtualizerAvailable = virtualizer != null && virtOk,
            virtualizerEnabled = safe { virtualizer?.enabled == true } ?: false,
            eqBands = bands,
            statusMessage = buildStatus(),
            statusOk = equalizer != null || bassBoost != null || virtualizer != null
        )
    }

    fun setVolumePercent(percent: Int) {
        val max = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        val target = (max * percent.coerceIn(0, 100) / 100f).toInt()
        audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, target, 0)
    }

    fun setBoost(enabled: Boolean) {
        boost = enabled
        safe { equalizer?.enabled = enabled }
        safe { bassBoost?.enabled = enabled }
        safe { virtualizer?.enabled = enabled }
    }

    fun setBass(enabled: Boolean) {
        safe { bassBoost?.enabled = enabled }
    }

    fun setVirtualizer(enabled: Boolean) {
        safe { virtualizer?.enabled = enabled }
    }

    fun setEqBand(index: Int, normalized: Float) {
        safe {
            val eq = equalizer ?: return@safe
            val count = eq.numberOfBands.toInt()
            if (index !in 0 until count) return@safe
            val value = (eqMin + (eqMax - eqMin) * normalized.coerceIn(0f, 1f)).toInt()
            eq.setBandLevel(index.toShort(), value.coerceIn(eqMin, eqMax).toShort())
        }
    }

    fun applyPreset(name: String) {
        val eq = equalizer ?: return
        val count = try { eq.numberOfBands.toInt() } catch (_: Exception) { return }
        val gains = when (name) {
            "Gaming" -> listOf(0.72f, 0.58f, 0.68f, 0.82f, 0.88f, 0.72f, 0.58f, 0.55f)
            "Music" -> listOf(0.82f, 0.76f, 0.62f, 0.52f, 0.58f, 0.72f, 0.84f, 0.88f)
            "Movies" -> listOf(0.84f, 0.72f, 0.55f, 0.58f, 0.72f, 0.82f, 0.78f, 0.72f)
            else -> listOf(0.42f, 0.55f, 0.78f, 0.86f, 0.78f, 0.62f, 0.48f, 0.40f)
        }
        for (i in 0 until count) {
            val normalized = gains[i.coerceAtMost(gains.lastIndex)]
            setEqBand(i, normalized)
        }
    }

    fun reset() {
        setBoost(false)
        safe { bassBoost?.enabled = false }
        safe { virtualizer?.enabled = false }
        val eq = equalizer
        if (eq != null) {
            val count = safe { eq.numberOfBands.toInt() } ?: 0
            for (i in 0 until count) safe { eq.setBandLevel(i.toShort(), 0) }
        }
    }

    private fun readBands(): List<EqBand> {
        val eq = equalizer ?: return emptyList()
        return try {
            val count = eq.numberOfBands.toInt()
            (0 until count).map { i ->
                val level = eq.getBandLevel(i.toShort()).toInt()
                val range = (eqMax - eqMin).coerceAtLeast(1)
                val centerHz = eq.getCenterFreq(i.toShort()) / 1000
                val label = when {
                    centerHz >= 1000 -> "${centerHz / 1000}k"
                    else -> "${centerHz}Hz"
                }
                EqBand(label, ((level - eqMin).toFloat() / range).coerceIn(0f, 1f), (level / 100).toInt())
            }
        } catch (_: Exception) { emptyList() }
    }

    private fun buildStatus(): String {
        val active = listOfNotNull(
            if (equalizer != null) "EQ" else null,
            if (bassBoost != null) "Bass" else null,
            if (virtualizer != null) "Virtualizer" else null
        )
        return if (active.isEmpty()) "No compatible global audio effects were created."
        else "Effect instances created: ${active.joinToString()} (session 0; device behavior may vary)."
    }

    private inline fun <T> safe(block: () -> T): T? =
        try { block() } catch (_: Exception) { null }

    fun release() {
        safe { equalizer?.release() }
        safe { bassBoost?.release() }
        safe { virtualizer?.release() }
        equalizer = null; bassBoost = null; virtualizer = null
    }
}
